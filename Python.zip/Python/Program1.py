print("Learner Report")

#ask student first name
student_name = input("Please enter your first name: \n")

#ask student last name
student_surname = input("Please enter your last name: \n")

#ask student age
student_age = int(input("Please enter your age \n"))

#ask student number
student_number = int(input("Please enter your student number: \n"))

#average variable to hold 3 marks per student, value 0
average_total = 0

#ask student to enter 4 marks
mark_1 = int(input("Please enter mark for Maths: \n"))
mark_2 = int(input("Please enter mark for Science: \n"))
mark_3 = int(input("Please enter mark for Engineering: \n"))
mark_4 = int(input("Please enter mark for Technology: \n"))

#calculating average for 4 marks by adding all and dividing by 4
average_total = int(((mark_1 + mark_2 + mark_3 + mark_4) / 4))

#printing results
print("Student First Name is :\n",student_name )
print("Student Last Name is :\n",student_surname)
print("Student age is :\n",student_age)
print("Student Number is :\n",student_number)
print("Total average mark is :\n",average_total)

if (mark_1 > mark_2) and (mark_1 > mark_3) and (mark_1 > mark_4):
    print("The highest_mark is : \n",mark_1)

elif (mark_2 > mark_1) and (mark_2 > mark_3) and (mark_2 > mark_4):
    print("The highest_mark is : \n",mark_2)
    
elif (mark_3 > mark_1) and (mark_3 > mark_2) and (mark_3 > mark_4):
    print("The highest_mark is : \n",mark_3)
    
else:
    print("The highest mark is : ", mark_4)

if average_total < 50:
    print("Sorry", student_name, "you have failed!")

if average_total >= 50 and average_total < 74:
    print("Welldone", student_name, ", you have passed!")

if average_total >= 75:
    print("CONGRADULATIONS", student_name, ", you have passed with Distinction!!!")






















    

        
                
